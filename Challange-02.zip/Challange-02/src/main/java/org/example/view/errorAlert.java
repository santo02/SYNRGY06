package org.example.view;

public class errorAlert {
    public void worngChoice(){
        System.out.println("Pilihan Tidak Tersedia !");
    }
}
