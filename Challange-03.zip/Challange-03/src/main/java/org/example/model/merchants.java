package org.example.model;

public class merchants {
}
