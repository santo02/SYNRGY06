package org.example.utils;

public class constants {
    public static final String BOLD_LINE = "==========================================";
    public static final String THIN_LINE = "------------------------------------------";
    public static  final String NEW_LINE = "\n";
    public static final String ONE_TAB = "\t";
    public static final String DOUBLE_TAB = "\t\t";
    public static final String PIPE = "|";

}
